


clc; clear; close all;
import edu.stanford.math.plex4.*;
import eulerCharacteristic.*



%% SW Example

max_dimension = 3;% max dimension of any simplex included
max_filtration_value = 16%0.9;
num_divisions = 1000;

% create the set of points
%load pointsTorusGrid.mat
load empatSW.mat
load empat.mat
%point_cloud = pointsTorusGrid;
point_cloud1 = empat
point_cloud2 = empatSW

size(point_cloud2)

% create a Vietoris-Rips stream 
stream = api.Plex4.createVietorisRipsStream(point_cloud2, max_dimension, max_filtration_value, num_divisions);
num_simplices = stream.getSize()

% get persistence algorithm over Z/2Z
%persistence = api.Plex4.getModularSimplicialAlgorithm(max_dimension, 2);
persistence = api.Plex4.getDefaultSimplicialAlgorithm(max_dimension);


% compute the intervals
intervals = persistence.computeIntervals(stream);

plot_barcodes(intervals);
% create the barcode plots
options.filename = 'ripsSW';
options.max_filtration_value = max_filtration_value; %the largest filtration value to be displayed;
options.max_dimension = max_dimension; % the largest persistent homology dimension to be displayed;
options.side_by_side = true;%so that betti barcodes of different dims are displayed side by side instead top=bottom
plot_barcodes(intervals, options);

% get the infinite barcodes
infinite_barcodes = intervals.getInfiniteIntervals();

% print out betti numbers array
betti_numbers_array = infinite_barcodes.getBettiSequence() %The computed semi-infinite intervals are merely those that persist until t = tmax
eulerCharacteristic(stream, max_dimension)



%subplot(1, 2, 1);
%scatter(point_cloud1(:,1), point_cloud1(:, 2));
%title("Shaft from Inventor");
%subplot(1, 2, 2);
%scatter(point_cloud2(:,1), point_cloud2(:, 2));
%title("Shaft from SolidWorks");