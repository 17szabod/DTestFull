%% Torus Example
clc; clear; close all;
import edu.stanford.math.plex4.*;
import eulerCharacteristic.*
max_dimension = 3;
max_filtration_value = 16%0.9;
num_divisions = 1000;

% create the set of points
%load pointsTorusGrid.mat
load empatInv_all.mat
%point_cloud = pointsTorusGrid;
point_cloud = empatInv_all
size(point_cloud)

% create a Vietoris-Rips stream 
streamA = api.Plex4.createVietorisRipsStream(point_cloud, max_dimension, max_filtration_value, num_divisions);

%% SW Example
% X(t) filtration for t={0, tmax/max_divisions,..., tmax}
max_dimension = 3;
max_filtration_value = 16%0.9; % must be greater than epsilon
num_divisions = 1000;

% create the set of points
%load pointsTorusGrid.mat
load empatSW_all.mat
%point_cloud = pointsTorusGrid;
point_cloud = empatSW_all
size(point_cloud)

% create a Vietoris-Rips stream 
streamB = api.Plex4.createVietorisRipsStream(point_cloud, max_dimension, max_filtration_value, num_divisions);




persistence = api.Plex4.getModularSimplicialAlgorithm(3, 2);

% compute and print the intervals
intervalsA = persistence.computeIntervals(streamA)
intervalsB = persistence.computeIntervals(streamB)

% compute the bottleneck distances
intervalsA_dim0=intervalsA.getIntervalsAtDimension(0);
intervalsB_dim0=intervalsB.getIntervalsAtDimension(0);
bottleneck_distance_dim0 = edu.stanford.math.plex4.bottleneck.BottleneckDistance.computeBottleneckDistance(intervalsA_dim0,intervalsB_dim0)
intervalsA_dim1=intervalsA.getIntervalsAtDimension(1);
intervalsB_dim1=intervalsB.getIntervalsAtDimension(1);
bottleneck_distance_dim1 = edu.stanford.math.plex4.bottleneck.BottleneckDistance.computeBottleneckDistance(intervalsA_dim1,intervalsB_dim1)
