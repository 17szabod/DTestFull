function m =sumTwoNum(a,b) 
    m = a + b; 
end 