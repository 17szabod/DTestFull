#!/bin/bash

povray +Itorus.pov +H600 +W800 +Q3 +A